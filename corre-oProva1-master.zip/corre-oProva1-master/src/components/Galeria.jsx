
export default function Galeria(){
    return(
        <div className="galeria">
            <img src="evento1.jpeg" alt="" />
            <img src="evento2.jpg" alt="" />
            <img src="evento3.jpg" alt="" />
            <img src="evento4.jpeg" alt="" />
            <img src="evento5.jpeg" alt="" />
            <img src="evento6.jpeg" alt="" />
        </div>
    )
}