function Rodape(){
    return(
        <footer>
            <p>emily - turma</p>
        </footer>
    )
}
export default Rodape