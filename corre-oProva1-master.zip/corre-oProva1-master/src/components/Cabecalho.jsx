export default function Cabecalho(){
    return(
        <header>
            <img src="senas.png" className="senas" />
        </header>
    )
}